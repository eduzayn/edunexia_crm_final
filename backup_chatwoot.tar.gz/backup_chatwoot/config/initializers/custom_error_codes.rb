Rack::Utils::HTTP_STATUS_CODES[901] = 'Trial Expired'
Rack::Utils::HTTP_STATUS_CODES[902] = 'Account Suspended'
