ActiveRecordQueryTrace.enabled = true if Rails.env.development?
