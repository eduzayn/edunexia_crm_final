export const REPLY_EDITOR_MODES = {
  REPLY: 'REPLY',
  NOTE: 'NOTE',
};

export const CHAR_LENGTH_WARNING = {
  UNDER_50: 'characters remaining',
  NEGATIVE: 'characters over',
};
