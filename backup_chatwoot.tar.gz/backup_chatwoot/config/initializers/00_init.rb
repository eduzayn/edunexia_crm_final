APPS_CONFIG = YAML.load_file(Rails.root.join('config/integration/apps.yml'))
